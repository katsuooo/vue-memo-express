<template>
  <div id="app">
    <div class="container">
      <h1>Click Confirm</h1>
      <p class="lead">Convenient and elegant inline user confirmation of UI events.</p>

      <div class="row">
        <div class="col-md-6 text-center">
          <click-confirm placement="bottom">
            <button class="btn btn-primary" @click="successAlert">Click me</button>
          </click-confirm>
        </div>
        <div class="col-md-6 text-center">
          <h4><a href="https://github.com/SirLamer/click-confirm">View on GitHub</a></h4>
        </div>
      </div>

      <p>
        This VueJS component prompts a user to confirm a click action as deliberate before allowing the event to
        proceed. The component wraps around any nested clickable element and intercepts any click event with a prompt
        request. The prompt appears immediately adjacent to the button without otherwise interrupting the page, making
        the experience faster and more comfortable for the user than a typical Javascript prompt.
      </p>

      <h4>Getting Started</h4>
      <p>Click Confirm depends on the following in your production environment:</p>
      <table class="table table-bordered table-hover">
        <thead class="thead-default">
        <tr>
          <th>Dependency</th>
          <th>Version</th>
          <th>Tested with</th>
          <th>Notes</th>
        </tr>
        </thead>
        <tbody>
        <tr>
          <td><a href="https://vuejs.org" target="_blank">VueJS</a></td>
          <td>2.0+</td>
          <td>2.5.16</td>
          <td>Why else would you be here?</td>
        </tr>
        <tr>
          <td><a href="https://v4-alpha.getbootstrap.com" target="_blank">Bootstrap</a></td>
          <td>4.0.0 (alpha)</td>
          <td>4.0.0-dev.11</td>
          <td>Uses CSS only, Bootstrap's Javascript package is not required.</td>
        </tr>
        <tr>
          <td><a href="http://fontawesome.io" target="_blank">Font Awesome</a></td>
          <td>4.0+, 5.0+</td>
          <td>4.7</td>
          <td>
            This may be safely excluded in order to not show icons on the buttons, or may be replaced with another
            icon typeset. See below.
          </td>
        </tr>
        </tbody>
      </table>

      <p>
        Click Confirm depends on <a href="https://bootstrap-vue.github.io" target="_blank">Bootstrap Vue</a> for use of
        its Popover component. Don't worry, this component will be pulled in automatically if you are not already using
        it.
      </p>
      <p>

      </p>
      <div class="row mt-2 mb-3">
        <div class="col-md-4">
          Pull Click Confirm in to your project via npm:
        </div>
        <div class="col-md-8">
          <pre><code>npm install click-confirm --save</code></pre>
        </div>
        <div class="col-md-4">
          The recommended use method is to include the ClickConfirm.vue file as part of your package generation.
        </div>
        <div class="col-md-8">
          <pre><code>import Vue from 'vue'
import ClickConfirm from 'click-confirm/src/ClickConfirm.vue'

Vue.component('clickConfirm', ClickConfirm);</code></pre>
        </div>
        <div class="col-md-4">
          If, for some reason, this is not an available option you can include the pre-bundled script, however this is
          inefficient and not recommended for a production environment.
        </div>
        <div class="col-md-8">
          <pre><code>import Vue from 'vue'
import ClickConfirm from 'click-confirm'

Vue.component('clickConfirm', ClickConfirm);</code></pre>
        </div>
      </div>

      <h4 id="the-basics">The Basics</h4>
      <p>
        Click Confirm will flexibly intercept any click events. This includes both native DOM events and VueJS
        events. Any emitted 'click' events will be intercepted and re-transmitted if confirmed via the popup prompt.
      </p>
      <div class="row">
        <div class="col-md-4 text-center">
          <p>
            <click-confirm>
              <a href="http://www.example.com" target="_blank">Typical URL link</a>
            </click-confirm>
          </p>
          <p>
            <click-confirm>
              <a href="http://www.example.com" class="btn btn-primary" role="button" target="_blank">URL link as button</a>
            </click-confirm>
          </p>
          <p>
            <click-confirm>
              <button class="btn btn-primary" onclick="alert('It worked!')">DOM 'onclick' event</button>
            </click-confirm>
          </p>
          <p>
            <click-confirm>
              <button class="btn btn-primary" @click="successAlert">VueJS @click event</button>
            </click-confirm>
          </p>
        </div>
        <div class="col-md-8">
          <pre><code>&lt;click-confirm&gt;
  &lt;a href="http://www.example.com" target="_blank"&gt;Typical URL link&lt;/a&gt;
&lt;/click-confirm&gt;

&lt;click-confirm&gt;
  &lt;a href="http://www.example.com" class="btn btn-primary"
          role="button" target="_blank"
  &gt;URL link as button&lt;/a&gt;
&lt;/click-confirm&gt;

&lt;click-confirm&gt;
  &lt;button class="btn btn-primary"
          onclick="alert('It worked!')"
  &gt;DOM 'onclick' event&lt;/button&gt;
&lt;/click-confirm&gt;

&lt;click-confirm&gt;
  &lt;button class="btn btn-primary"
          @click="successAlert"
  &gt;VueJS @click event&lt;/button&gt;
&lt;/click-confirm&gt;</code></pre>
        </div>
      </div>
      <p>
        Subsequent demonstrations all use a Javascript alert for brevity.
      </p>

      <h4>Properties</h4>
      <p>All properties on the Click Confirm component are optional. Demonstrations are provided below.</p>
      <table class="table table-bordered table-hover">
        <thead class="thead-default">
        <tr>
          <th>Property</th>
          <th>Data Type(s)</th>
          <th>Default</th>
          <th>Description</th>
        </tr>
        </thead>
        <tbody>
        <tr>
          <th scope="row"><code>button-size</code></th>
          <td><code>"sm"</code>, <code>""</code> (medium), or <code>"lg"</code></td>
          <td><code>""</code></td>
          <td>Render size of confirmation buttons, per Bootstrap 4.</td>
        </tr>
        <tr>
          <th scope="row"><code>copy-attributes</code></th>
          <td>String, Array</td>
          <td><code>["href", "target"]</code></td>
          <td>
            Attributes from enclosed element which will be copied to the 'yes' button. Intended for copying a URL
            to the 'yes' button, but it is customizable.
          </td>
        </tr>
        <tr>
          <th scope="row"><code>disabled</code></th>
          <td>Boolean</td>
          <td><code>false</code></td>
          <td>
            Suppresses the click-confirm dialogue and allows the click event to proceed as normal. If set to 'true'
            while the Click Confirm popover it being displayed, the popover will be suppressed.
          </td>
        </tr>
        <tr>
          <th scope="row"><code>messages</code></th>
          <td>Object, formatted per Default</td>
          <td><code>{
            title: 'Are you sure?',
            yes: 'Yes',
            no: 'No'
            }</code></td>
          <td>
            Messages displayed within the confirmation dialogue. All or part of the object properties may be
            included; any missing will be displayed per the default values. This design is intended to make
            multi-language support straightforward.
          </td>
        </tr>
        <tr>
          <th scope="row"><code>no-class</code></th>
          <td>String, Array, Object</td>
          <td><code>"btn btn-secondary"</code></td>
          <td>Class to use for the 'No' button, can be used for further styling.</td>
        </tr>
        <tr>
          <th scope="row"><code>container</code></th>
          <td>String, null</td>
          <td><code>"my-custom-element-id"</code></td>
          <td>(Inherited from Bootstrap Vue popover component)<a href="https://bootstrap-vue.js.org/docs/components/popover##component-reference" target="_blank">Bootstrap-Vue docs</a>
            Element string ID to append rendered popover into. If null or element not found, popover is appended to
            <code>"body"</code> (default)
          </td>
        </tr>
        <tr>
          <th scope="row"><code>no-icon</code></th>
          <td>String, Array, Object</td>
          <td><code>"fa fa-times"</code></td>
          <td>Typeset icon visible within the 'No' button.</td>
        </tr>
        <tr>
          <th scope="row"><code>placement</code></th>
          <td>String</td>
          <td><code>"top"</code></td>
          <td>Display location of the confirmation popover per <a href="https://bootstrap-vue.js.org/docs/components/popover#positioning" target="_blank">Bootstrap-Vue docs</a>.</td>
        </tr>
        <tr>
          <th scope="row"><code>yes-icon</code></th>
          <td>String, Array, Object</td>
          <td><code>"fa fa-check"</code></td>
          <td>Typeset icon visible within the 'Yes' button.</td>
        </tr>
        <tr>
          <th scope="row"><code>yes-class</code></th>
          <td>String, Array, Object</td>
          <td><code>"btn btn-primary"</code></td>
          <td>Class to use for the 'Yes' button, can be used for further styling.</td>
        </tr>
        </tbody>
      </table>

      <h4>Placement</h4>
      <p>
        Like Bootstrap Popover, the confirmation prompt can be displayed on any side of the target.
      </p>
      <div class="row">
        <div class="col-md-4">
          <div class="row">
            <div class="col-12 text-center">
              <p>
                <click-confirm placement="bottom">
                  <button class="btn btn-primary" @click="successAlert">Bottom</button>
                </click-confirm>
              </p>
            </div>
            <div class="col-6">
              <p>
                <click-confirm placement="right">
                  <button class="btn btn-primary" @click="successAlert">Right</button>
                </click-confirm>
              </p>
            </div>
            <div class="col-6 text-right">
              <p>
                <click-confirm placement="left">
                  <button class="btn btn-primary" @click="successAlert">Left</button>
                </click-confirm>
              </p>
            </div>
            <div class="col-12 text-center">
              <p>
                <click-confirm>
                  <button class="btn btn-primary" @click="successAlert">Top (default)</button>
                </click-confirm>
              </p>
            </div>
          </div>
        </div>
        <div class="col-md-8">
          <pre><code>&lt;click-confirm placement="bottom"&gt;
  &lt;button class="btn btn-primary" @click="successAlert"&gt;Bottom&lt;/button&gt;
&lt;/click-confirm&gt;

&lt;click-confirm placement="right"&gt;
  &lt;button class="btn btn-primary" @click="successAlert"&gt;Right&lt;/button&gt;
&lt;/click-confirm&gt;

&lt;click-confirm placement="left"&gt;
  &lt;button class="btn btn-primary" @click="successAlert"&gt;Left&lt;/button&gt;
&lt;/click-confirm&gt;

&lt;click-confirm&gt;
  &lt;button class="btn btn-primary" @click="successAlert"&gt;Top (default)&lt;/button&gt;
&lt;/click-confirm&gt;</code></pre>
        </div>
      </div>

      <h4>Multi-Language Support</h4>
      <p>
        Supporting multiple languages is simple. The object-based structure is intended to make implementing multiple
        languages straightforward.
      </p>
      <div class="row">
        <div class="col-md-4 text-center">
          <p>
            <click-confirm>
              <button class="btn btn-primary" @click="successAlert">English (default)</button>
            </click-confirm>
          </p>
          <p>
            <click-confirm :messages="{title: 'Êtes-vous sûr?', yes: 'Oui', no: 'Non'}">
              <button class="btn btn-primary" @click="successAlert">Français</button>
            </click-confirm>
          </p>
          <p>
            <click-confirm :messages="{title: 'I am Groot?', yes: 'I am Groot', no: 'I am Groot'}">
              <button class="btn btn-primary" @click="successAlert">Groot</button>
            </click-confirm>
          </p>
        </div>
        <div class="col-md-8">
          <pre><code>&lt;click-confirm&gt;
  &lt;button class="btn btn-primary" @click="successAlert"&gt;English (default)&lt;/button&gt;
&lt;/click-confirm&gt;

&lt;click-confirm
          :messages="{title: 'Êtes-vous sûr?', yes: 'Oui', no: 'Non'}"&gt;
  &lt;button class="btn btn-primary" @click="successAlert"&gt;Français&lt;/button&gt;
&lt;/click-confirm&gt;

&lt;click-confirm
          :messages="{title: 'I am Groot?', yes: 'I am Groot', no: 'I am Groot'}"&gt;
  &lt;button class="btn btn-primary" @click="successAlert"&gt;Groot&lt;/button&gt;
&lt;/click-confirm&gt;</code></pre>
        </div>
      </div>

      <h4>Button Icons</h4>
      <p>
        Click Confirm ships configured to use Font Awesome's 'check' (for yes) and 'times' (for no) icons. You can
        provide alternate CSS classes to apply to the button's 'span' element. Any other CSS-based icon library, such as
        Glyphicons, may also be used. In order to allow this, you must include all prefix class names required by your
        desired icon library.
      </p>
      <div class="row">
        <div class="col-md-4 text-center">
          <p>
            <click-confirm>
              <button class="btn btn-primary" @click="successAlert">Check and X (default)</button>
            </click-confirm>
          </p>
          <p>
            <click-confirm yes-icon="fa fa-thumbs-up" no-icon="fa fa-thumbs-down">
              <button class="btn btn-primary" @click="successAlert">All thumbs</button>
            </click-confirm>
          </p>
          <p>
            <click-confirm yes-icon="fa fa-smile-o fa-spin" no-icon="fa fa-frown-o fa-spin">
              <button class="btn btn-primary" @click="successAlert">Turn that frown upside-down</button>
            </click-confirm>
          </p>
        </div>
        <div class="col-md-8">
          <pre><code>&lt;click-confirm&gt;
  &lt;button class="btn btn-primary" @click="successAlert"&gt;Check and X (default)&lt;/button&gt;
&lt;/click-confirm&gt;

&lt;click-confirm yes-icon="fa fa-thumbs-up" no-icon="fa fa-thumbs-down"&gt;
  &lt;button class="btn btn-primary" @click="successAlert"&gt;All thumbs&lt;/button&gt;
&lt;/click-confirm&gt;

&lt;click-confirm yes-icon="fa fa-smile-o fa-spin" no-icon="fa fa-frown-o fa-spin"&gt;
  &lt;button class="btn btn-primary" @click="successAlert"&gt;Turn that frown upside-down&lt;/button&gt;
&lt;/click-confirm&gt;</code></pre>
        </div>
      </div>

      <h4>Button Classes</h4>
      <p>
        Click Confirm ships configured to use Bootstraps's 'btn-primary' (for yes) and 'btn-secondary' (for no) classes.
        You can provide alternate CSS classes to apply to the button's 'a' element, thus allowing for more detailed
        styling of the buttons. The styles provides will be merged with the 'button-size' classes, so the button size
        should not be included in this property.
      </p>
      <div class="row">
        <div class="col-md-4 text-center">
          <p>
            <click-confirm>
              <button class="btn btn-primary" @click="successAlert">btn-primary and btn-secondary (default)</button>
            </click-confirm>
          </p>
          <p>
            <click-confirm yes-class="btn btn-success" no-class="btn btn-danger">
              <button class="btn btn-primary" @click="successAlert">Green and red buttons</button>
            </click-confirm>
          </p>
        </div>
        <div class="col-md-8">
        <pre><code>&lt;click-confirm&gt;
  &lt;button class="btn btn-primary" @click="successAlert"&gt;Check and X (default)&lt;/button&gt;
&lt;/click-confirm&gt;

&lt;click-confirm yes-class="btn btn-success" no-class="btn btn-danger"&gt;
  &lt;button class="btn btn-primary" @click="successAlert"&gt;All thumbs&lt;/button&gt;
&lt;/click-confirm&gt;</code></pre>
        </div>
      </div>

      <h4>Button Size</h4>
      <p>
        The confirmation button size is customizable.
      </p>
      <div class="row">
        <div class="col-md-4 text-center">
          <p>
            <click-confirm>
              <button class="btn btn-primary" @click="successAlert">Medium (default)</button>
            </click-confirm>
          </p>
          <p>
            <click-confirm button-size="sm">
              <button class="btn btn-primary" @click="successAlert">Small</button>
            </click-confirm>
          </p>
          <p>
            <click-confirm button-size="lg">
              <button class="btn btn-primary" @click="successAlert">Large</button>
            </click-confirm>
          </p>
        </div>
        <div class="col-md-8">
        <pre><code>&lt;click-confirm&gt;
  &lt;button class="btn btn-primary" @click="successAlert"&gt;Medium (default)&lt;/button&gt;
&lt;/click-confirm&gt;

&lt;click-confirm button-size="sm"&gt;
  &lt;button class="btn btn-primary" @click="successAlert"&gt;Small&lt;/button&gt;
&lt;/click-confirm&gt;

&lt;click-confirm button-size="lg"&gt;
  &lt;button class="btn btn-primary" @click="successAlert"&gt;Large&lt;/button&gt;
&lt;/click-confirm&gt;</code></pre>
        </div>
      </div>

      <h4>Disable</h4>
      <p>
        The confirmation feature can be programmatically suppressed, which will allow the click event to proceed uninterrupted.
      </p>
      <div class="row">
        <div class="col-md-4 text-center">
          <p>
            <click-confirm>
              <button class="btn btn-primary" @click="successAlert">Enabled (default)</button>
            </click-confirm>
          </p>
          <p>
            <click-confirm :disabled="true">
              <button class="btn btn-primary" @click="successAlert">Disabled</button>
            </click-confirm>
          </p>
        </div>
        <div class="col-md-8">
        <pre><code>&lt;click-confirm&gt;
  &lt;button class="btn btn-primary" @click="successAlert"&gt;Enabled (default)&lt;/button&gt;
&lt;/click-confirm&gt;

&lt;click-confirm :disabled="true"&gt;
  &lt;button class="btn btn-primary" @click="successAlert"&gt;Small&lt;/button&gt;
&lt;/click-confirm&gt;</code></pre>
        </div>
      </div>

      <h4>Icon Slots</h4>
      <p>
        The button icons may optionally be replaced via the named slots <code>confirm-yes-icon</code> and <code>confirm-no-icon</code>. Use this to use your own custom icon solution, for example, if you want to use <a href="https://fontawesome.com/how-to-use/on-the-web/using-with/vuejs" target="_blank">Font Awesome 5's vue-fontawesome package</a> for rendering icons from Javascript-embedded SVGs.
      </p>
      <pre><code>&lt;click-confirm&gt;
  &lt;button class="btn btn-primary" @click="successAlert"&gt;Default icons&lt;/button&gt;
&lt;/click-confirm&gt;

&lt;click-confirm&gt;
  &lt;template slot="confirm-yes-icon"&gt;
    &lt;vue-font-awesome :icon="['far', 'check']"&gt;&lt;/vue-font-awesome&gt;
  &lt;/template&gt;
  &lt;template slot="confirm-yes-icon"&gt;
    &lt;vue-font-awesome :icon="['far', 'times']"&gt;&lt;/vue-font-awesome&gt;
  &lt;/template&gt;
  &lt;button class="btn btn-primary" @click="successAlert"&gt;Custom icons&lt;/button&gt;
&lt;/click-confirm&gt;</code></pre>

      <h4>Custom Appearance</h4>
      <p>
        The Click Confirm popover is enclosed in a CSS element and class <code>"div.click-confirm"</code>. This allows you to customize the
        appearance using CSS scoped within this parent class. Please study the code on GitHub or a rendered example from
        above to learn how to target the desired elements.
      </p>

    </div>
  </div>
</template>

<script>
  export default {
    methods: {
        successAlert() {
            alert('It worked!');
        }
    }
  }
</script>
